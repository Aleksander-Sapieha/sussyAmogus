import setuptools
setuptools.setup(
    name='sussyAmogus',
    version='0.4',
    author='guard_games',
    author_email='sourceguy68@gmail.com',
    description='a sus pip package',
    packages=setuptools.find_packages(),
    install_requiers = [],
    keywords=['python', 'sus', 'sussy', 'susamogus', 'sussy baka', 'amogus'],
     classifiers=[
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Operating System :: Unix",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]
)