class ejected():

    def __init__(self, name):
        self.name = name

    def ejectname(name):
        print(f"{name} was ejected")

    class imposter():
        def __init__(self, name):
            self.name = name

        def yes(name):
           print(f"{name} was an imposter")

        def no(name):
            print(f"{name} was not an imposter")